-- FuBoxUI Radial Menu - v0.2 2017-08-12
-- by Andrew Hazelden <andrew@andrewhazelden.com>
-- Based upon proof of concept code from Peter Loveday

-- The source code is distributed under the GNU General Public License version 3.

-- Usage: Press the ESC key over the Fusion Viewer windows to pop up the new FuBoxUI Radial menu. It is designed to work over image viewer and Fusion 3D workspace views but unique layouts could be triggered elsewhere.

-- If your graphics card has insufficient support for hardware overlays with transparency then you won't see the UI with a transparent background.

local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local width,height = 300,200

win = disp:AddWindow(
{
	ID = 'FuBoxWin',
	WindowFlags = { Popup = true, WindowStaysOnTopHint = true },

	Margin = 0,

	ui:VGroup
	{
		Spacing = 10,
		Geometry = { 0, 0, width, height },

		ui:HGroup
		{
			Spacing = 10,
			ui:HGap(0, .5),
			ui:Button{ ID = 'A', Text = 'A' },
			ui:HGap(0, .5),
		},
		ui:HGroup
		{
			Spacing = 10,
			ui:HGap(0, .25),
			ui:Button{ ID = 'B', Text = 'B' },
			ui:HGap(0, .25),
			ui:Button{ ID = 'C', Text = 'C' },
			ui:HGap(0, .25),
		},
		ui:HGroup
		{
			Spacing = 10,
			ui:Button{ ID = 'D', Text = 'D' },
			ui:HGap(0, 0.4),
			ui:Button{ ID = 'FuBox', Text = '🇨🇦 FuBox' },
			ui:HGap(0, 0.4),
			ui:Button{ ID = 'E', Text = 'E' },
		},
		ui:HGroup
		{
			Spacing = 10,
			ui:HGap(0, .25),
			ui:Button{ ID = 'F', Text = 'F' },
			ui:HGap(0, .25),
			ui:Button{ ID = 'H', Text = 'H' },
			ui:HGap(0, .25),
		},
	  ui:HGroup
		{
			Spacing = 10,
			ui:HGap(0, .5),
			ui:Button{ ID = 'I', Text = 'I' },
			ui:HGap(0, .5),
		},
	}
})

-- Find out the current operating system platform. The platform local variable should be set to either 'Windows', 'Mac', or 'Linux'.
local platform = ''
if string.find(comp:MapPath('Fusion:\\'), 'Program Files', 1) then
  -- Check if the OS is Windows by searching for the Program Files folder
  platform = 'Windows'
elseif string.find(comp:MapPath('Fusion:\\'), 'PROGRA~1', 1) then
  -- Check if the OS is Windows by searching for the Program Files folder
  platform = 'Windows'
elseif string.find(comp:MapPath('Fusion:\\'), 'Applications', 1) then
  -- Check if the OS is Mac by searching for the Applications folder
  platform = 'Mac'
else
  platform = 'Linux'
end

-- Open a web browser window up with the help documentation
function openBrowser()
  command = ''
  webpage = 'http://www.andrewhazelden.com'
  
  if platform == 'Windows' then
    -- Running on Windows
    command = 'explorer "' .. webpage .. '"'
  elseif platform == 'Mac' then
    -- Running on Mac
    command = 'open "' .. webpage .. '" &' 
  elseif platform == 'Linux' then
    -- Running on Linux
    command = 'xdg-open "' .. webpage .. '" &'
  end
  
  -- print('[Launch Command] ', command)
  os.execute(command)
end

-- Init Window
win:Move({mousex - width/2, mousey - height/2})
win:SetAttribute('WA_TranslucentBackground', true)
itm = win:GetItems()

-- Handle Window Events

function win.On.A.Clicked(ev)
	disp:ExitLoop()
end

function win.On.B.Clicked(ev)
	disp:ExitLoop()
end

function win.On.C.Clicked(ev)
	disp:ExitLoop()
end

function win.On.D.Clicked(ev)
	disp:ExitLoop()
end

function win.On.E.Clicked(ev)
	disp:ExitLoop()
end

function win.On.F.Clicked(ev)
	disp:ExitLoop()
end

function win.On.G.Clicked(ev)
	disp:ExitLoop()
end

function win.On.H.Clicked(ev)
	disp:ExitLoop()
end

function win.On.I.Clicked(ev)
	disp:ExitLoop()
end

function win.On.FuBox.Clicked(ev)
  print('FuBoxUI by Andrew Hazelden <andrew@andrewhazelden.com>')
  openBrowser()
	disp:ExitLoop()
end

win:Show()
disp:RunLoop()
win:Hide()
