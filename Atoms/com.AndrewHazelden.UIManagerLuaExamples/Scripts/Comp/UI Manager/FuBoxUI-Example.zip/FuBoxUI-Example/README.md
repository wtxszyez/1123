# FuBoxUI v0.2 - 2017-08-12 #

by Andrew Hazelden [andrew@andrewhazelden.com](mailto:andrew@andrewhazelden.com)  
web: [www.andrewhazelden.com](http://www.andrewhazelden.com)  

## Overview ##

This script is a Fusion lua based example that shows how a Maya "Marking Menu" like UI can be created with Fusion 9's new UI Manager GUI Library. This script is intended primarily as a fu.UIManager GUI example that shows how to make a new transparent window, and then add several buttons arranged in a radial layout.

A Emoji icon is placed in the center button text label. This center "FuBox" button is linked to a Lua openBrowser() function that opens up your Windows/Mac/Linux default webbrowser to the [www.andrewhazelden.com](http://www.andrewhazelden.com)   webpage. This serves as an example of how you could place a link to help documentation, or your company website in a FuBoxUI button.

The source code is distributed under the GNU General Public License version 3.

## Screenshot ##

This is a preview of what the FuBoxUI looks like when you press the ESC key on your keyboard:

![FuBoxUI Screenshot](FuBoxUI-Screenshot.png)

## Usage ##
Press the ESC key over the Fusion Viewer windows to pop up the new FuBoxUI radial menu. It is designed to work over image viewer and Fusion 3D workspace views but unique layouts could be triggered elsewhere.

If your graphics card has insufficient support for hardware overlays with transparency then you won't see the UI with a transparent background.


## Installation ##

**Step 1.** Copy the hotkey file "FuBoxUI.fu" and the "FuBoxUI.lua" script to your Fusion user preferences "Config" folder.

**Step 2.** Restart Fusion

**Step 3.** Click in the Fusion Image Viewer window or in a Fusion's 3D workspace view to set the active focus. Then tap the ESC "escape" key to toggle the FuBoxUI window. 

**Note:** If you press the ESC key multiple times you will see multiple FuBoxUI windows appear. Clicking on any of the buttons will close the UI.
