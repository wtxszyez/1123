--[[
Fusion RSS Headlines v1 - 2017-09-09 10.19 AM
by Andrew Hazelden  
Email: [andrew@andrewhazelden.com](mailto:andrew@andrewhazelden.com)  
Web: [www.andrewhazelden.com](http://www.andrewhazelden.com)  

## Overview ##

The "Fusion RSS Headlines.lua" script runs on MacOS and uses the [Lua-Feeds module](http://code.matthewwild.co.uk/lua-feeds) to display live RSS news feeds inside of the Fusion 8.2.1/Fusion 9 compositing package. The GUI for the RSS reader script is based upon a ui:Tree layout in the new UI Manager system.

At this point in time the "Fusion RSS Headlines.lua" script only works with Fusion on MacOS since the Linux and Windows based Lua "luaexpat", "luasocket", and "luasec" module installation instructions have not been prepared or tested.

## Installation ##

### MacOS Install Steps (done via the Terminal.app) ###

Step 1. Add the Brew package manager from [https://brew.sh/](https://brew.sh/):

    /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"

Step 2. Use Brew to install wget and lua5.1 with https support:

    brew install wget lua51 luajit pcre openssl

Step 3. Add the luarocks package manager:

    wget https://luarocks.org/releases/luarocks-2.4.1.tar.gz
    tar zxpf luarocks-2.4.1.tar.gz
    cd luarocks-2.4.1
    ./configure; sudo make bootstrap

Step 4. Use luarocks to install the luasockets, luaexpat, and luasec modules:

    sudo luarocks install luaexpat
    sudo luarocks install luasocket
    sudo luarocks install luasec OPENSSL_DIR=/usr/local/opt/openssl

Step 5. Open the lua library folders once so you know where they are for the future:

    open "/usr/local/lib/lua/5.1/"
    open "/usr/local/share/lua/5.1/"

Step 6. Install the Fusion RSS Headlines Lua scripts:

Copy the "install/Scripts/Comp/Fusion RSS Headlines.lua" script to the Fusion 8.2.1+ user prefs "Scripts/Comp/" folder.

Copy the contents of the "install/share/lua/5.1/" folder to the "/usr/local/share/lua/5.1/" folder. You might have to change the folder permissions so you have write access to the folder.

Step 7. In Fusion run the **Script > Fusion RSS Headlines** menu item to open the RSS reader.

## Todos ##

Download and process the inline images from the article content and description tags

]]

-- -----------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------

-- Fusion RSS Feeds:
rssFeeds = {}
rssFeeds[1] = {id = 1, url = 'https://www.steakunderwater.com/wesuckless/feed.php', name = 'We Suck Less RSS'}
rssFeeds[2] = {id = 2, url = 'https://www.blackmagicdesign.com/rss', name = 'Blackmagic Design RSS'}
rssFeeds[3] = {id = 3, url = 'http://www.andrewhazelden.com/blog/feed/', name = 'Andrew Hazelden RSS'}
rssFeeds[4] = {id = 4, url = 'http://www.comp-fu.com/feed/atom/', name = '[Tilt] Stefan Ihringer RSS'}
rssFeeds[5] = {id = 5, url = 'http://nvrfall.com/feed/', name = '[NSF] Duri Kral RSS'}
rssFeeds[6] = {id = 6, url = 'http://www.svenneve.com/?feed=rss2', name = '[svenneve] Sven Neve RSS'}
rssFeeds[7] = {id = 7, url = 'http://www.bryanray.name/wordpress/feed/', name = '[Midgardsormr] Bryan Ray RSS'}
rssFeeds[8] = {id = 8, url = 'http://framehaus.net/feed/', name = '[Togtobias] Tobias Steiner RSS'}
rssFeeds[9] = {id = 9, url = 'http://www.designimage.co.uk/feed/', name = '[Kenzor] Ken Turner RSS'}
rssFeeds[10] = {id = 10, url = 'http://wordpress.empty98.de/?feed=rss2', name = '[PingKing] Michael Vorberg Blog RSS'}
rssFeeds[11] = {id = 11, url = 'https://reichofevil.wordpress.com/feed/', name = '[PingKing] Reich of Evil RSS'}
rssFeeds[12] = {id = 13, url = 'https://indicated.com/feed/', name = '[Chad] Chad Capeland / Indicated RSS'}
rssFeeds[13] = {id = 12, url = 'http://www.siredric.de/wordpress/feed/', name = '[SirEdric] Eric Westphal RSS'}


-- List the RSS Feed entries
print('[RSS Feeds]')
-- dump(rssFeeds)
for i = 1, table.getn(rssFeeds) do
  print('[Site] ' .. rssFeeds[i].name .. '[URL] ' .. rssFeeds[i].url)
end

-- Find out if we are running Fusion 6, 7, or 8
fu_major_version = math.floor(tonumber(eyeon._VERSION))

-- Find out the current operating system platform. The platform local variable should be set to either 'Windows', 'Mac', or 'Linux'.
platform = ''
if string.find(comp:MapPath('Fusion:\\'), 'Program Files', 1) then
  -- Check if the OS is Windows by searching for the Program Files folder
  platform = 'Windows'
elseif string.find(comp:MapPath('Fusion:\\'), 'PROGRA~1', 1) then
  -- Check if the OS is Windows by searching for the Program Files folder
  platform = 'Windows'
elseif string.find(comp:MapPath('Fusion:\\'), 'Applications', 1) then
  -- Check if the OS is Mac by searching for the Applications folder
  platform = 'Mac'
else
  platform = 'Linux'
end


-- Access Lua-Feeds
require 'feeds/feeds'

-- Access http based luasockets
local http = require('socket.http')

-- Access https based luasockets
local https = require('ssl.https')
local ltn12 = require('ltn12')

-- Create a Fusion UI Manager window
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)
local width,height = 900,800

win = disp:AddWindow({
  ID = 'MyWin',
  WindowTitle = 'Fusion RSS Headlines',
  Geometry = {0, 0, width, height},
  Margin = 10,
  Spacing = 10,
  
	ui:VGroup{
	  ID = 'root',
    -- Add your GUI elements here:
      	  
	  ui:HGroup{
      Weight = 0,
      ui:Label{ID = 'TitleLabel', Text = 'The Fusion RSS Reader allows you to stay up to date with the latest Fusion news!', Alignment = { AlignHCenter = true, AlignTop = true }},
      ui:ComboBox{ID = 'RSSSourceCombo', Text = 'RSS Source'},
    },
      
    ui:VGroup{
      -- List the RSS headlines
      ui:Tree{ID = 'Tree', SortingEnabled=true, Events = {ItemDoubleClicked=true, ItemClicked=true}}, 
      
      -- Tool Usage Caption
      ui:HGroup{
        Weight = 0,
        ui:Label{ID = 'CommentLabel', Text = 'Single click on a row to preview the article. Double click on a row to open the article in your webbrowser.', Alignment = {AlignHCenter = true, AlignTop = true }},
      },
      
      -- HTML Preview Section
      ui:HGroup{
        Weight = 0.5,
        ui:TextEdit{ID = 'HTMLPreview', ReadOnly = true},
      }, 
    },
  },
})

-- Add your GUI element based event functions here:
itm = win:GetItems()


-- The window was closed
function win.On.MyWin.Close(ev)
    disp:ExitLoop()
end

-- The RSS Source ComboControl was updated
function win.On.RSSSourceCombo.CurrentIndexChanged(ev)
  UpdateTree()
end

-- Copy the RSS feel url to the clipboard when a Tree view row is clicked on
function win.On.Tree.ItemClicked(ev)
  -- Column 1 = RSS Headline
  headline = ev.item.Text[0]
  
  -- Column 2 = URL
  url = ev.item.Text[1]

  print('[' .. rssFeeds[itm.RSSSourceCombo.CurrentIndex + 1].name .. ' Headline] ' .. headline)

  -- Add content to the HTML preview window
  for i, entry in ipairs(feedString) do
    -- only process if the selected Tree row matches the current RSS url
    if url == entry:get_child('link').attr.href then
      -- Read the RSS content or description tag from the feed
      if itm.RSSSourceCombo.CurrentIndex == 0 then
        -- On the We Suck Less site read the RSS content tag
        itm.HTMLPreview.HTML = entry:get_child('content'):get_text()
      else
        -- All of the other entries are blogs so read the RSS summary tag
        itm.HTMLPreview.HTML = entry:get_child('summary'):get_text()
      end
    end
  end
  
  -- List the HTML formatted RSS summary contents
  -- print('[HTML] ' .. tostring(itm.HTMLPreview.HTML))

end

-- Open up the URL in your webbrowser when a Tree view row is clicked on
function win.On.Tree.ItemDoubleClicked(ev)
  -- Column 2 = URL
  url = ev.item.Text[1]
  
	-- Open up the URL
  OpenURL(url)
    
	-- Copy the url to the clipboard
  CopyToClipboard(url)
end


-- Update the contents of the tree view
function UpdateTree()
  -- Clean out the previous entries in the Tree view
  itm.Tree:Clear()

  -- Load the selected RSS feed
  -- print('[RSS Source Combo Index] ', itm.RSSSourceCombo.CurrentIndex)

  -- The URL for the Fusion RSS feed (Note: .CurrentIndex starts at 0):
  feedURL = rssFeeds[itm.RSSSourceCombo.CurrentIndex + 1].url

  -- Check if the connection is https or http based
  if feedURL:match('http:') then
    -- http URL:
    -- Download the luasocket based rss content
    content, response, header = http.request(feedURL)
    print('[HTTP Connection] ', feedURL)
    dump('[Response Code] ', response)
    -- dump('[Headers] ', header)
    -- dump('[Content] ', content)
    
    -- Open the RSS using the Lua-Feeds module from an http URL
    -- feedString = feeds.open_http(feedURL)
    
    -- Parse the RSS feed as a string
    feedString = feeds.feed_from_string(content)
  else
    -- https URL:
    local contentTable = {}
    local returnCode, response, header, status = https.request{
      url = feedURL,
      sink = ltn12.sink.table(contentTable)
    }
    
    -- Merge the table array back into a single string
    content = table.concat(contentTable)
  
    print('[HTTPS Connection] ', feedURL)
    dump('[Response Code] ', response)
    -- dump('[Headers] ', header)
    -- dump('[Status] ', status)
    -- dump('[Return Code] ', returnCode)
    -- dump('[Content] ', content)
    
    -- Parse the RSS feed as a string
    feedString = feeds.feed_from_string(content)

    -- Legacy Debugging:
    -- Read a saved .rss file off disk
    -- local feedfp = io.open(feedFilepath, 'r'):read('*all')
    -- feedString = feeds.feed_from_string(feedfp)
  end
  
  itm.MyWin.WindowTitle = 'Fusion RSS Headlines - ' .. feedURL

  -- Add the Tree headers:
  -- RSS Headline                             URL
  -- Fusion • .dds file support in fusion?    https://www.steakunderwater.com/wesuckless/viewtopic.php?t=1464&p=10762#p10762
  hdr = itm.Tree:NewItem()
  hdr.Text[0] = 'RSS Headline'
  hdr.Text[1] = 'URL'
  
  itm.Tree:SetHeaderItem(hdr)

  -- Number of columns in the Tree list
  itm.Tree.ColumnCount = 2

  -- Resize the header column widths
  itm.Tree.ColumnWidth[0] = 360
  itm.Tree.ColumnWidth[1] = 500

  -- -----------------------------------------------------------------------------------------------------

  -- Add an new RSS row entry to the Tree
  for i, entry in ipairs(feedString) do
      itLoader = itm.Tree:NewItem()
      
      -- Read the RSS title and decode the HTML entity strings
      itLoader.Text[0] = DecodeHTMLEntity(entry:get_child('title'):get_text());
      
      -- Read the RSS link
      itLoader.Text[1] = entry:get_child('link').attr.href
      
      -- Add the new entries to the table
      itm.Tree:AddTopLevelItem(itLoader)
  end
end


-- Open up the URL with the operating system's default handler
-- Note: This function expects an http or https link and will not translate a local absolute filepath into a browser based file:/// path.
function OpenURL(path)
  command = nil

  -- Open a folder view using the os native command
  if platform == 'Windows' then
    -- Running on Windows
    command = 'explorer "' .. path .. '"'
    
    -- print("[Launch Command] ", command)
    os.execute(command)
  elseif platform == 'Mac' then
    -- Running on Mac
    command = 'open "' .. path .. '" &'
          
    -- print("[Launch Command] ", command)
    os.execute(command)
  elseif platform == 'Linux' then
    -- Running on Linux
    command = 'nautilus "' .. path .. '" &'
          
    -- print("[Launch Command] ", command)
    os.execute(command)
  else
    print('[Platform] ', platform)
    print('There is an invalid platform defined in the local platform variable at the top of the code.')
  end
  
  print('[Opening URL] ' .. path)
end

-- Find out the current directory from a file path
-- Example: print(Dirname("/Users/Shared/file.txt"))
function Dirname(mediaDirName)
-- LUA Dirname command inspired by Stackoverflow code example:
-- http://stackoverflow.com/questions/9102126/lua-return-directory-path-from-path
  sep = ''
  
  if platform == 'Windows' then
    sep = '\\'
  elseif platform == 'Mac' then
    sep = '/'
  else
    -- Linux
    sep = '/'
  end
  
  return mediaDirName:match('(.*' .. sep .. ')')
end


-- Copy text to the operating system's clipboard
-- Example: CopyToClipboard('Hello World!')
function CopyToClipboard(textString)
  -- The system temporary directory path (Example: $TEMP/Fusion/)
  outputDirectory = comp:MapPath('Temp:\\Fusion\\')
  clipboardTempFile = outputDirectory .. 'ClipboardText.txt'

  -- Create the temp folder if required
  os.execute('mkdir "' .. outputDirectory .. '"')

  -- Open up the file pointer for the output textfile
  outClipFile, err = io.open(clipboardTempFile,'w')
  if err then
    print("[Error Opening Clipboard Temporary File for Writing]")
    return
  end

  outClipFile:write(textString,'\n')

  -- Close the file pointer on the output textfile
  outClipFile:close()

  if platform == 'Windows' then
    -- The Windows copy to clipboard command is "clip"
    command = 'clip < "' .. clipboardTempFile .. '"'
  elseif platform == 'Mac' then
    -- The Mac copy to clipboard command is "pbcopy"
    command = 'pbcopy < "' .. clipboardTempFile .. '"'
  elseif platform == 'Linux' then
    -- The Linux copy to clipboard command is "xclip"
    -- This requires a custom xclip tool install on Linux:
 
    -- Debian/Ubuntu:
    -- sudo apt-get install xclip
 
    -- Redhat/Centos/Fedora:
    -- yum install xclip
    command = 'cat "' .. clipboardTempFile .. '" | xclip -selection clipboard &'
  end

  print('[Copy to Clipboard] ' .. textString)
  os.execute(command)
end


-- Decode HTML entity items in a string
-- Example: local content = DecodeHTMLEntity('&lt;html&gt;')
function DecodeHTMLEntity(str)
  if str ~= nil then
    entity = {}
    entity[1] = { encoded = '&amp;', decoded = '&'}
    entity[2] = { encoded = '&AMP;', decoded = '&'}
    entity[3] = { encoded = '&apos;', decoded = "'"}
    entity[4] = { encoded = '&excl;', decoded = '!'}
    entity[5] = { encoded = '&GT;', decoded = '>'}
    entity[6] = { encoded = '&gt', decoded = '>'}
    entity[7] = { encoded = '&lpar;', decoded = '('}
    entity[8] = { encoded = '&lt;', decoded = '<'}
    entity[9] = { encoded = '&LT;', decoded = '<'}
    entity[10] = { encoded = '&NewLine;', decoded = '\n'}
    entity[11] = { encoded = '&percnt;', decoded = '%%'}
    entity[12] = { encoded = '&quot;', decoded = '"'}
    entity[13] = { encoded = '&QUOT;', decoded = '"'}
    entity[14] = { encoded = '&rpar;', decoded = ')'}
    entity[15] = { encoded = '&semi;', decoded = ';'}
    entity[16] = { encoded = '&Tab;', decoded = '	'}

    -- Scan through the entity table and apply a string replace command for each item
    for i = 1, table.getn(entity) do
      str = str:gsub(entity[i].encoded, entity[i].decoded)
    end
  else
    str = ''
  end
  
  return str
end

-- -----------------------------------------------------------------------------------------------------

-- Add the RSS feed site name entries to the ComboControl menu
for i = 1, table.getn(rssFeeds) do
  itm.RSSSourceCombo:AddItem(rssFeeds[i].name)
end

-- Update the contents of the tree view
-- UpdateTree()

win:Show()
disp:RunLoop()
win:Hide()
