# Fusion RSS Headlines v1 - 2017-09-09 10.10 AM #
by Andrew Hazelden  
Email: [andrew@andrewhazelden.com](mailto:andrew@andrewhazelden.com)  
Web: [www.andrewhazelden.com](http://www.andrewhazelden.com)  

---

## Overview ##

The "Fusion RSS Headlines.lua" script runs on MacOS and uses the [Lua-Feeds module](http://code.matthewwild.co.uk/lua-feeds) to display live RSS news feeds inside of the Fusion 8.2.1/Fusion 9 compositing package. The GUI for the RSS reader script is based upon a ui:Tree layout in the new UI Manager system.

At this point in time the "Fusion RSS Headlines.lua" script only works with Fusion on MacOS since the Linux and Windows based Lua "luaexpat", "luasocket", and "luasec" module installation instructions have not been prepared or tested.

![Fusion RSS Reader](images/fusion-rss-reader.png)

## Installation ##

### MacOS Install Steps (done via the Terminal.app) ###

Step 1. Add the Brew package manager from [https://brew.sh/](https://brew.sh/):

    /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"

Step 2. Use Brew to install wget and lua5.1 with https support:

    brew install wget lua51 luajit pcre openssl

Step 3. Add the luarocks package manager:

    wget https://luarocks.org/releases/luarocks-2.4.1.tar.gz
    tar zxpf luarocks-2.4.1.tar.gz
    cd luarocks-2.4.1
    ./configure; sudo make bootstrap

Step 4. Use luarocks to install the luasockets, luaexpat, and luasec modules:

    sudo luarocks install luaexpat
    sudo luarocks install luasocket
    sudo luarocks install luasec OPENSSL_DIR=/usr/local/opt/openssl

Step 5. Open the lua library folders once so you know where they are for the future:

    open "/usr/local/lib/lua/5.1/"
    open "/usr/local/share/lua/5.1/"

Step 6. Install the Fusion RSS Headlines Lua scripts:

Copy the "install/Scripts/Comp/Fusion RSS Headlines.lua" script to the Fusion 8.2.1+ user prefs "Scripts/Comp/" folder.

Copy the contents of the "install/share/lua/5.1/" folder to the "/usr/local/share/lua/5.1/" folder. You might have to change the folder permissions so you have write access to the folder.

Step 7. In Fusion run the **Script > Fusion RSS Headlines** menu item to open the RSS reader.
