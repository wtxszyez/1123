--[[--
Selected Node Count HUD - v1 2018-01-07
by Andrew Hazelden <andrew@andrewhazelden.com>

This tool shows a transparent HUD overlay that displays the number of selected nodes in the flow area.

Example Output: 
Selected Node Count: 25

## Installation ##

Step 1. Copy the "Selected Node Count HUD.fu" and "Selected Node Count HUD.lua" files into your Fusion user prefs "Config:/" folder.

Step 2. Restart Fusion. This will reload the .fu file and activate the hotkey.

## Usage ## 

Step 1. Select several nodes in the Fusion flow area.

Step 2. Press the "Shift + ESC" hotkey to quickly show the selected node count in a HUD popup window element. After 2 seconds the HUD overlay disappears.

If your graphics card has insufficient support for hardware overlays with transparency then you won't see the UI with a transparent background and will see a grey window outline instead.
--]]--


-- Tip: The # symbol put before a Lua table returns a count of how many items are in the table
local selectedNodes = "\nSelected Node Count: " .. tostring(#comp:GetToolList(true))
print(selectedNodes)

local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)
local width,height = 200,50

win = disp:AddWindow({
	ID = 'NodeCountWin',
	TargetID = "NodeCountWin",
	Geometry = {0, 0, width, height},
	WindowFlags = {
		Popup = true,
		WindowStaysOnTopHint = true,
	},
	
	ui:VGroup{
		ID = 'root',

		-- Add a "Selected Node Count:" Label
		ui:Label{
			ID = "nodeCountLabel",
			Text = selectedNodes,
			Alignment = {
				AlignHCenter = true,
				AlignVCenter = true,
			},
		},

	},
})


-- Reposition the window next to the mouse cursor
win:Move({mousex - (width/2), mousey - (height/2) - 30})

-- Enable window transparency
win:SetAttribute('WA_TranslucentBackground', true)

-- Add your GUI element based event functions here:
itm = win:GetItems()

-- Add support for manually closing the window on Windows 7 
function win.On.NodeCountWin.Clicked(ev)
	disp:ExitLoop()
end

win:Show()

-- Pause for 2 seconds then close the window
bmd.wait(2)
disp:ExitLoop()
