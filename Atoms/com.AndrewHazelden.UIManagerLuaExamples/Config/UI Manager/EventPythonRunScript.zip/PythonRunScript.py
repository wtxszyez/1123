# This script will be run externally by our Event
from pprint import pprint

# Get the active node selection
selection = 'None' if comp.ActiveTool is None else comp.ActiveTool.Name

# Print the results
pprint('[Selected Node] ' + str(selection))